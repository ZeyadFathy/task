<template>
<div class="container">
<nav class="navbar navbar-light bg-light">
  <span class="navbar-brand mb-0 h1">Navbar</span>
</nav></div> </template>

<script>
    export default {
        data() {
            return {
                companies: [] ,
                   company:{
                    name: '',
                    address: '',
                    website: '',
                    email: '',
                },
                company_id:'',
                paginateion:'',
                edit:false,
                }
            },
           created(){
           this.fetchComp();
           },

        methods: {
            fetchComp() {
                fetch('api/Companies')
                .then(res=> res.json())
                .then(res=>{console.log(res.data);})
                }

        }
    }
</script>