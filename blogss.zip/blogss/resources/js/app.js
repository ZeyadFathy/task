
require('./bootstrap');

window.Vue = require('vue');

import VueRouter from 'vue-router';

Vue.component('Companies', require('./components/Companies.vue'));

window.Vue.use(VueRouter);

import CompaniesIndex from './components/companies/CompaniesIndex.vue';
import CompaniesCreate from './components/companies/CompaniesCreate.vue';
import CompaniesEdit from './components/companies/CompaniesEdit.vue';
//import Companies from './components/companies/Companies.vue';


const routes = [
    {
        path: '/all',
        components: {
            companiesIndex: CompaniesIndex
        }
    },
    {
        path: '/admin/company/create', component: CompaniesCreate, name: 'createCompany'
    },
    {
        path: '/admin/company/edit/:id', component: CompaniesEdit, name: 'editCompany'
    },
]

const router = new VueRouter({ routes })

const app = new Vue({
    'el': '#app'
});