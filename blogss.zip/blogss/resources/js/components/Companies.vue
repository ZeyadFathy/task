
<template>

    <div class="container">
        <form @submit.prevent="addcompany" class="mb-3">
          <div class="form-group">
            <input type="text" class="form-control" placeholder="name" v-model="company.name">
            <input type="text" class="form-control" placeholder="email" v-model="company.email">
            <input type="text" class="form-control" placeholder="website" v-model="company.website">
            <input type="text" class="form-control" placeholder="address" v-model="company.address">
            <!-- <input type="hidden" class="form-control" placeholder="address" v-model="company._token"> -->
            
        </div>
        <button type="submit" class="btn btn-light btn-block">Save</button>
    </form>
    <nav aria-label="Page navigation example">
      <ul class="pagination">
        <li v-bind:class="[{disabled: !pagination.prev_page_url}]" class="page-item"><a class="page-link" href="#" @click="fetchcomp(pagination.prev_page_url)">Previous</a></li>

        <li class="page-item disabled"><a class="page-link text-dark" href="#">Page {{ pagination.current_page }} of {{ pagination.last_page }}</a></li>

        <li v-bind:class="[{disabled: !pagination.next_page_url}]" class="page-item"><a class="page-link" href="#" @click="fetchcomp(pagination.next_page_url)">Next</a></li>
    </ul>
</nav>
<div class="card card-body mb-2" v-for="company in companies" v-bind:key="company.id">
  <h3>{{ company.name }}</h3>
  <p>{{ company.address }}</p>
  <p>{{ company.website }}</p>
  <p>{{ company.email }}</p>
  <hr>
  <button @click="editcompany(company)" class="btn btn-warning mb-2">Edit</button>

  <button @click="deletecompany(company.id)" class="btn btn-danger">Delete</button> 
</div>
</div>
</template>

<script>
    export default {
      data() {
        return {
         companies: [] ,
         company:{
            name: '',
            address: '',
            website: '',
            email: '',
            _token: '',
        },
        company_id: '',
        pagination: {},
        edit: false
    };
},
created() {
    this.fetchcomp();
},
methods: {
    fetchcomp(page_url) {
      let vm = this;
      page_url = page_url || '/api/company/all';
      fetch(page_url)
      .then(res => res.json())
      .then(res => {
          this.companies = res.data;
          vm.makePagination(res.meta, res.links);
      })
      .catch(err => console.log(err));
  },
  makePagination(meta, links) {
      let pagination = {
        current_page: meta.current_page,
        last_page: meta.last_page,
        next_page_url: links.next,
        prev_page_url: links.prev
    };
    this.pagination = pagination;
},deletecompany(id) {
      if (confirm('Are You Sure?')) {
        fetch(`api/company/delete/${id}`, {
          method: 'delete'
        })
          .then(res => res.json())
          .then(data => {
            alert('company Removed');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
      }
    },

addcompany() {
      if (this.edit === false) {
        // Add
        etch('api/company/create', {
          method: 'post',
          body: JSON.stringify(this.company),
          headers: {
            'content-type': 'application/json'
        }
        })
          .then(res => res.json())
          .then(data => {
            this.clearForm();
            alert('company Added');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
      } else {
        // Update
        fetch('api/company/update/', {
          method: 'put',
          body: JSON.stringify(this.company),
          headers: {
            'content-type': 'application/json'
          }
        })
          .then(res => res.json())
          .then(data => {
            this.clearForm();
            alert('company Updated');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
      }
    },
    editcompany(company) {
      this.edit = true;
    this.company.id = company.id;
    this.company.company_id = company.id;
    this.company.name = company.name;
    this.company.website = company.website;
    this.company.email = company.email;
    this.company.address = company.address;
    },
   
  }
};
</script>


















