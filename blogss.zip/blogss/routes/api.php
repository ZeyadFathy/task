<?php
Route::middleware('auth:api')->get('/user', function (Request $request) {
	return $request->user();
});

Route::group([
	'prefix'=>'company'
], function(){
Route::get('all', 'CompanyController@index');
Route::get('get/{id}', 'CompanyController@show');
Route::post('create', 'CompanyController@store');
Route::put('update', 'CompanyController@update');
Route::delete('delete/{id}', 'CompanyController@destroy');
});

// // List articles
// Route::get('Companies', 'CompanyController@index');
// // List single article
// Route::get('company/{id}', 'CompanyController@show');
// // Create new article
// Route::post('company', 'CompanyController@store');

// // Update article
// Route::put('company', 'CompanyController@update');
// // Delete article
// Route::delete('company/{id}', 'CompanyController@destroy');
