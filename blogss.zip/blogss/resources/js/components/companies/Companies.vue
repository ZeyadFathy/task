<template>
<div>
<h2>Companies</h2>
    <div class="card card-body mb-2" v-for="company in Companies" v-bind:key="company.id">
      <h3>{{ company.name }}</h3>
      <p>{{ company.address }}</p>
      <p>{{ company.website }}</p>
      <p>{{ company.email }}</p>
      <hr>
      <button @click="deletecompany(company.id)" class="btn btn-danger">Delete</button> 
      </div>
</div>
</div>
 </template>

<script>
export default {
  data() {
     return {
                Companies: [] ,
                   company:{
                    name: '',
                    address: '',
                    website: '',
                    email: '',
                },
      company_id: '',
      pagination: {},
      edit: false
    };
  },
  created() {
    this.fetchcomp();
  },
  methods: {
    fetchcomp(page_url) {
      let vm = this;
      page_url = page_url || '/api/Companies';
      fetch(page_url)
        .then(res => res.json())
        .then(res => {
          this.Companies = res.data;
          vm.makePagination(res.meta, res.links);
        })
        .catch(err => console.log(err));
    },
    makePagination(meta, links) {
      let pagination = {
        current_page: meta.current_page,
        last_page: meta.last_page,
        next_page_url: links.next,
        prev_page_url: links.prev
      };
      this.pagination = pagination;
    },
        deletecompany(id) {
      if (confirm('Are You Sure?')) {
        fetch(`api/company/${id}`, {
          method: 'delete'
        })
          .then(res => res.json())
          .then(data => {
            alert('company Removed');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
      }
      },
       addcompany() {
      if (this.edit === false) {
        // Add
        fetch('api/company', {
          method: 'POST',
          body: JSON.stringify(this.Companies),
          headers: {
            'content-type': 'application/json'
          }
        })
          .then(res => res.json())
          .then(data => {
          this.clearForm();
            alert('company Added');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
     } else {
        // Update
        fetch('api/company', {
          method: 'put',
          body: JSON.stringify(this.Companies),
          headers: {
            'content-type': 'application/json'
          }
        })
          .then(res => res.json())
          .then(data => {
            this.clearForm();
            alert('company Updated');
            this.fetchcomp();
          })
          .catch(err => console.log(err));
      }
    },
    editCompany(company) {
      this.edit = true;
      this.company.id = company.id;
      this.company.Company_id = company.id;
      this.company.name = company.name;
      this.company.website = company.website;
      this.company.email = company.email;
      this.company.address = company.address;

    },
    clearForm() {
      this.edit = false;
      this.company.id = null;
      this.company.Company_id = null;
      this.company.name = '';
      this.company.website = '';
      this.company.email = '';
      this.company.address = '';
    }
  }
};